package com.tuansa.app.util

import java.text.Normalizer

object VietnameseText {
    fun stripDiacritics(input: String): String {
        val normalized = Normalizer.normalize(input, Normalizer.Form.NFD)
        return normalized
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("đ", "d")
            .replace("Đ", "D")
    }
}

