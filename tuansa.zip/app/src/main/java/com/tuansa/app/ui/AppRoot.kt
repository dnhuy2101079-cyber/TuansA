package com.tuansa.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tuansa.app.AppGraph
import com.tuansa.app.ui.manage.ManageScreen
import com.tuansa.app.ui.order.GuestCountScreen
import com.tuansa.app.ui.order.OrderScreen
import com.tuansa.app.ui.order.OrderViewModel
import com.tuansa.app.ui.order.TableSelectScreen

@Composable
fun AppRoot() {
    val navController = rememberNavController()

    val orderVmFactory = remember {
        AppViewModelFactory {
            OrderViewModel(
                menuRepository = AppGraph.menuRepository,
                printerRepository = AppGraph.printerRepository,
                orderRepository = AppGraph.orderRepository,
            )
        }
    }
    val orderViewModel: OrderViewModel = viewModel(factory = orderVmFactory)

    NavHost(navController = navController, startDestination = "tables") {
        composable("tables") {
            TableSelectScreen(
                onTableSelected = { zone, table ->
                    navController.navigate("guests/$zone/$table")
                },
                onOpenManage = { navController.navigate("manage") },
            )
        }

        composable(
            route = "guests/{zone}/{table}",
            arguments = listOf(
                navArgument("zone") { type = NavType.StringType },
                navArgument("table") { type = NavType.IntType },
            ),
        ) { backStackEntry ->
            val zone = backStackEntry.arguments?.getString("zone").orEmpty()
            val table = backStackEntry.arguments?.getInt("table") ?: 0
            GuestCountScreen(
                zone = zone,
                table = table,
                onBack = { navController.popBackStack() },
                onGuestCountConfirmed = { guests ->
                    navController.navigate("order/$zone/$table/$guests") {
                        popUpTo("tables") { saveState = false }
                    }
                },
            )
        }

        composable(
            route = "order/{zone}/{table}/{guests}",
            arguments = listOf(
                navArgument("zone") { type = NavType.StringType },
                navArgument("table") { type = NavType.IntType },
                navArgument("guests") { type = NavType.IntType },
            ),
        ) { backStackEntry ->
            val zone = backStackEntry.arguments?.getString("zone").orEmpty()
            val table = backStackEntry.arguments?.getInt("table") ?: 0
            val guests = backStackEntry.arguments?.getInt("guests") ?: 0
            OrderScreen(
                zone = zone,
                table = table,
                guests = guests,
                orderViewModel = orderViewModel,
                onDone = {
                    navController.navigate("tables") {
                        popUpTo("tables") { inclusive = true }
                    }
                },
                onOpenManage = { navController.navigate("manage") },
            )
        }

        composable("manage") {
            ManageScreen(
                onBack = { navController.popBackStack() },
            )
        }
    }
}

