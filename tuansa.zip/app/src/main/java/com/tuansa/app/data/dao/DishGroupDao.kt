package com.tuansa.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.tuansa.app.data.entity.DishGroupEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DishGroupDao {
    @Query("SELECT * FROM dish_groups ORDER BY sortOrder ASC, id ASC")
    fun observeAll(): Flow<List<DishGroupEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DishGroupEntity): Long

    @Update
    suspend fun update(entity: DishGroupEntity)

    @Delete
    suspend fun delete(entity: DishGroupEntity)
}

