package com.tuansa.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.tuansa.app.data.entity.PrinterEntity
import com.tuansa.app.data.entity.PrinterRole
import kotlinx.coroutines.flow.Flow

@Dao
interface PrinterDao {
    @Query("SELECT * FROM printers ORDER BY id DESC")
    fun observeAll(): Flow<List<PrinterEntity>>

    @Query("SELECT * FROM printers WHERE role = :role ORDER BY id DESC")
    suspend fun getByRole(role: PrinterRole): List<PrinterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: PrinterEntity): Long

    @Update
    suspend fun update(entity: PrinterEntity)

    @Delete
    suspend fun delete(entity: PrinterEntity)
}

