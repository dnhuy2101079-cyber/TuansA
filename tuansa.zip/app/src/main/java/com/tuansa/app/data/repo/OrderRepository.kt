package com.tuansa.app.data.repo

import com.tuansa.app.data.dao.DishDao
import com.tuansa.app.data.dao.OrderDao
import com.tuansa.app.data.dao.OrderItemDao
import com.tuansa.app.data.entity.DishEntity
import com.tuansa.app.data.entity.OrderEntity
import com.tuansa.app.data.entity.OrderItemEntity

data class OrderLineInput(
    val dishId: Long,
    val quantity: Int,
    val addOnDishIds: List<Long> = emptyList(),
)

data class OrderLineResolved(
    val dish: DishEntity,
    val quantity: Int,
    val addOns: List<DishEntity>,
)

data class OrderPrintData(
    val order: OrderEntity,
    val lines: List<OrderLineResolved>,
)

class OrderRepository(
    private val orderDao: OrderDao,
    private val orderItemDao: OrderItemDao,
    private val dishDao: DishDao,
) {
    suspend fun createOrder(
        zone: String,
        tableNumber: Int,
        guests: Int,
        note: String?,
        lines: List<OrderLineInput>,
        createdAtEpochMillis: Long,
    ): Long {
        val orderId = orderDao.insert(
            OrderEntity(
                zone = zone,
                tableNumber = tableNumber,
                guests = guests,
                note = note?.takeIf { it.isNotBlank() },
                createdAtEpochMillis = createdAtEpochMillis,
            ),
        )
        val entities = lines.map {
            OrderItemEntity(
                orderId = orderId,
                dishId = it.dishId,
                quantity = it.quantity,
                addOnDishIds = it.addOnDishIds,
            )
        }
        orderItemDao.insertAll(entities)
        return orderId
    }

    suspend fun loadPrintData(orderId: Long): OrderPrintData? {
        val order = orderDao.getById(orderId) ?: return null
        val items = orderItemDao.getByOrderId(orderId)
        val dishIds = items.flatMap { listOf(it.dishId) + it.addOnDishIds }.distinct()
        val dishes = dishDao.getByIds(dishIds).associateBy { it.id }
        val lines = items.mapNotNull { item ->
            val dish = dishes[item.dishId] ?: return@mapNotNull null
            val addOns = item.addOnDishIds.mapNotNull { dishes[it] }
            OrderLineResolved(
                dish = dish,
                quantity = item.quantity,
                addOns = addOns,
            )
        }
        return OrderPrintData(order = order, lines = lines)
    }
}

