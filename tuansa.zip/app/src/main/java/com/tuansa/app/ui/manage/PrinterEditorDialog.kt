package com.tuansa.app.ui.manage

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tuansa.app.data.entity.PrinterEntity
import com.tuansa.app.data.entity.PrinterRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrinterEditorDialog(
    initial: PrinterEntity?,
    onDismiss: () -> Unit,
    onSave: (id: Long, name: String, ip: String, port: Int, role: PrinterRole, stripDiacritics: Boolean) -> Unit,
    onTest: (ip: String, port: Int, stripDiacritics: Boolean) -> Unit,
) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var ip by remember { mutableStateOf(initial?.ip.orEmpty()) }
    var portText by remember { mutableStateOf((initial?.port ?: 9100).toString()) }
    var roleIndex by remember { mutableIntStateOf(if (initial?.role == PrinterRole.KITCHEN) 0 else 1) }
    var strip by remember { mutableStateOf(initial?.stripDiacritics ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    val port = portText.toIntOrNull() ?: 9100
                    val role = if (roleIndex == 0) PrinterRole.KITCHEN else PrinterRole.CASHIER
                    onSave(initial?.id ?: 0, name, ip, port, role, strip)
                },
                enabled = name.trim().isNotBlank() && ip.trim().isNotBlank(),
            ) {
                Text("Lưu")
            }
        },
        dismissButton = { Button(onClick = onDismiss) { Text("Hủy") } },
        title = { Text(if ((initial?.id ?: 0) == 0L) "Thêm máy in" else "Sửa máy in") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(top = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Tên máy in") },
                )
                OutlinedTextField(
                    value = ip,
                    onValueChange = { ip = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("IP") },
                    placeholder = { Text("Ví dụ: 192.168.1.50") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                )
                OutlinedTextField(
                    value = portText,
                    onValueChange = { portText = it.filter { ch -> ch.isDigit() } },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Port (mặc định 9100)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                )
                Text(
                    text = "Loại máy in",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { roleIndex = 0 }, modifier = Modifier.weight(1f)) { Text("Bếp") }
                    Button(onClick = { roleIndex = 1 }, modifier = Modifier.weight(1f)) { Text("Quầy") }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Bỏ dấu khi in",
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Switch(checked = strip, onCheckedChange = { strip = it })
                }
                Button(
                    onClick = {
                        val port = portText.toIntOrNull() ?: 9100
                        if (ip.trim().isNotBlank()) onTest(ip.trim(), port, strip)
                    },
                    enabled = ip.trim().isNotBlank(),
                ) {
                    Text("In thử")
                }
            }
        },
    )
}

