package com.tuansa.app.data.repo

import com.tuansa.app.data.dao.PrinterDao
import com.tuansa.app.data.entity.PrinterEntity
import com.tuansa.app.data.entity.PrinterRole
import kotlinx.coroutines.flow.Flow

class PrinterRepository(
    private val printerDao: PrinterDao,
) {
    fun observeAll(): Flow<List<PrinterEntity>> = printerDao.observeAll()

    suspend fun getByRole(role: PrinterRole): List<PrinterEntity> = printerDao.getByRole(role)

    suspend fun upsert(entity: PrinterEntity): Long = printerDao.upsert(entity)

    suspend fun delete(entity: PrinterEntity) = printerDao.delete(entity)
}

