package com.tuansa.app.data.repo

import com.tuansa.app.data.dao.DishDao
import com.tuansa.app.data.dao.DishGroupDao
import com.tuansa.app.data.entity.DishEntity
import com.tuansa.app.data.entity.DishGroupEntity
import kotlinx.coroutines.flow.Flow

class MenuRepository(
    private val dishGroupDao: DishGroupDao,
    private val dishDao: DishDao,
) {
    fun observeGroups(): Flow<List<DishGroupEntity>> = dishGroupDao.observeAll()
    fun observeDishes(): Flow<List<DishEntity>> = dishDao.observeAll()

    suspend fun upsertGroup(entity: DishGroupEntity): Long = dishGroupDao.upsert(entity)
    suspend fun deleteGroup(entity: DishGroupEntity) = dishGroupDao.delete(entity)

    suspend fun upsertDish(entity: DishEntity): Long = dishDao.upsert(entity)
    suspend fun deleteDish(entity: DishEntity) = dishDao.delete(entity)
}

