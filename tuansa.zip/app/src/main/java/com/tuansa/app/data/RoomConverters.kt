package com.tuansa.app.data

import androidx.room.TypeConverter
import com.tuansa.app.data.entity.PrinterRole
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.parseToJsonElement

class RoomConverters {
    private val json = Json { ignoreUnknownKeys = true }

    @TypeConverter
    fun longListToString(value: List<Long>?): String {
        return json.encodeToString(value ?: emptyList())
    }

    @TypeConverter
    fun stringToLongList(value: String?): List<Long> {
        if (value.isNullOrBlank()) return emptyList()
        return decodeLongList(value)
    }

    @TypeConverter
    fun printerRoleToString(value: PrinterRole): String = value.name

    @TypeConverter
    fun stringToPrinterRole(value: String?): PrinterRole {
        return runCatching { PrinterRole.valueOf(value ?: "") }.getOrDefault(PrinterRole.CASHIER)
    }

    private fun decodeLongList(value: String): List<Long> {
        val element = json.parseToJsonElement(value)
        return json.decodeFromJsonElement<List<Long>>(element)
    }
}
