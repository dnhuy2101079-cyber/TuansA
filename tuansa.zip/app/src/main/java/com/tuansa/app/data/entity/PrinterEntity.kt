package com.tuansa.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class PrinterRole {
    KITCHEN,
    CASHIER,
}

@Entity(tableName = "printers")
data class PrinterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val ip: String,
    val port: Int = 9100,
    val role: PrinterRole = PrinterRole.CASHIER,
    val stripDiacritics: Boolean = true,
)

