package com.tuansa.app.ui.order

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.tuansa.app.data.entity.DishEntity
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderScreen(
    zone: String,
    table: Int,
    guests: Int,
    orderViewModel: OrderViewModel,
    onDone: () -> Unit,
    onOpenManage: () -> Unit,
) {
    val groups by orderViewModel.groups.collectAsStateWithLifecycle()
    val dishes by orderViewModel.dishes.collectAsStateWithLifecycle()
    val draftLines by orderViewModel.draftLines.collectAsStateWithLifecycle()
    val note by orderViewModel.note.collectAsStateWithLifecycle()
    val checkoutResult by orderViewModel.checkoutResult.collectAsStateWithLifecycle()

    var tabIndex by remember { mutableIntStateOf(0) }

    val dishesById = remember(dishes) { dishes.associateBy { it.id } }
    val selected = remember(draftLines, dishesById) {
        draftLines.values.mapNotNull { line ->
            val dish = dishesById[line.dishId] ?: return@mapNotNull null
            dish to line.quantity
        }.sortedBy { it.first.name }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("$zone - Bàn $table ($guests khách)") },
                actions = {
                    IconButton(onClick = onOpenManage) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Quản lý")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            TabRow(selectedTabIndex = tabIndex) {
                Tab(
                    selected = tabIndex == 0,
                    onClick = { tabIndex = 0 },
                    text = { Text("Món") },
                )
                Tab(
                    selected = tabIndex == 1,
                    onClick = { tabIndex = 1 },
                    text = { Text("Đã chọn (${selected.sumOf { it.second }})") },
                )
            }

            when (tabIndex) {
                0 -> DishList(
                    groups = groups.map { it.id to it.name },
                    dishes = dishes,
                    qtyById = draftLines.mapValues { it.value.quantity },
                    onAdd = orderViewModel::addDish,
                    onRemove = orderViewModel::removeDish,
                )

                else -> SelectedList(
                    selected = selected,
                    onAdd = { orderViewModel.addDish(it.id) },
                    onRemove = { orderViewModel.removeDish(it.id) },
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = note,
                    onValueChange = orderViewModel::setNote,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Ghi chú đơn hàng (không bắt buộc)") },
                )
                Button(
                    onClick = { orderViewModel.checkoutAndPrint(zone, table, guests) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = checkoutResult !is CheckoutResult.Printing,
                ) {
                    Text("Thanh toán & In bill")
                }
                Button(
                    onClick = {
                        orderViewModel.clearDraft()
                        onDone()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = checkoutResult !is CheckoutResult.Printing,
                ) {
                    Text("Hủy & Chọn bàn khác")
                }
            }
        }

        if (checkoutResult is CheckoutResult.Printing) {
            AlertDialog(
                onDismissRequest = {},
                confirmButton = {},
                title = { Text("Đang in...") },
                text = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        CircularProgressIndicator()
                        Text("Vui lòng chờ máy in nhận dữ liệu.")
                    }
                },
            )
        }

        if (checkoutResult is CheckoutResult.Success) {
            AlertDialog(
                onDismissRequest = {},
                confirmButton = {
                    Button(
                        onClick = {
                            orderViewModel.clearDraft()
                            onDone()
                        },
                    ) {
                        Text("Xong")
                    }
                },
                title = { Text("Hoàn tất") },
                text = { Text("Đã in bill cho $zone - Bàn $table.") },
            )
        }

        if (checkoutResult is CheckoutResult.Error) {
            val message = (checkoutResult as CheckoutResult.Error).message
            AlertDialog(
                onDismissRequest = { orderViewModel.clearDraft() },
                confirmButton = {
                    Button(onClick = { orderViewModel.clearDraft() }) {
                        Text("Đóng")
                    }
                },
                title = { Text("Lỗi") },
                text = { Text(message) },
            )
        }
    }
}

@Composable
private fun DishList(
    groups: List<Pair<Long, String>>,
    dishes: List<DishEntity>,
    qtyById: Map<Long, Int>,
    onAdd: (Long) -> Unit,
    onRemove: (Long) -> Unit,
) {
    val groupNameById = remember(groups) { groups.associate { it.first to it.second } }
    val grouped = remember(dishes) {
        dishes.groupBy { it.groupId }.toList().sortedBy { (groupId, _) -> groupId ?: Long.MAX_VALUE }
    }
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        grouped.forEach { (groupId, list) ->
            item(key = "header-$groupId") {
                val name = groupId?.let { groupNameById[it] } ?: "Khác"
                Text(
                    text = name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Spacer(modifier = Modifier.height(6.dp))
            }
            items(list, key = { it.id }) { dish ->
                DishRow(
                    dish = dish,
                    qty = qtyById[dish.id] ?: 0,
                    onAdd = { onAdd(dish.id) },
                    onRemove = { onRemove(dish.id) },
                )
            }
        }
        if (dishes.isEmpty()) {
            item("empty") {
                Text(
                    text = "Chưa có món. Vào Quản lý để thêm món.",
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
        }
    }
}

@Composable
private fun DishRow(
    dish: DishEntity,
    qty: Int,
    onAdd: () -> Unit,
    onRemove: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(modifier = Modifier.height(56.dp)) {
            val path = dish.imagePath
            if (!path.isNullOrBlank()) {
                AsyncImage(
                    model = File(path),
                    contentDescription = dish.name,
                    modifier = Modifier.height(56.dp),
                )
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = dish.name,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Medium,
            )
            if (dish.suggestedAddOnIds.isNotEmpty()) {
                Text(
                    text = "Có bán kèm",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        if (qty > 0) {
            IconButton(onClick = onRemove) {
                Icon(imageVector = Icons.Default.Remove, contentDescription = "Giảm")
            }
            Text(
                text = qty.toString(),
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.SemiBold,
            )
        }
        IconButton(onClick = onAdd) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Thêm")
        }
    }
}

@Composable
private fun SelectedList(
    selected: List<Pair<DishEntity, Int>>,
    onAdd: (DishEntity) -> Unit,
    onRemove: (DishEntity) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(selected, key = { it.first.id }) { (dish, qty) ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = dish.name,
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.onBackground,
                )
                IconButton(onClick = { onRemove(dish) }) {
                    Icon(imageVector = Icons.Default.Remove, contentDescription = "Giảm")
                }
                Text(
                    text = qty.toString(),
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.SemiBold,
                )
                IconButton(onClick = { onAdd(dish) }) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Thêm")
                }
            }
        }
        if (selected.isEmpty()) {
            item("empty-selected") {
                Text(
                    text = "Chưa chọn món nào.",
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
        }
    }
}
