package com.tuansa.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.tuansa.app.data.entity.DishEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DishDao {
    @Query("SELECT * FROM dishes ORDER BY id DESC")
    fun observeAll(): Flow<List<DishEntity>>

    @Query("SELECT * FROM dishes WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<DishEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DishEntity): Long

    @Update
    suspend fun update(entity: DishEntity)

    @Delete
    suspend fun delete(entity: DishEntity)
}

