package com.tuansa.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.tuansa.app.ui.AppRoot
import com.tuansa.app.ui.theme.TuansATheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TuansATheme {
                AppRoot()
            }
        }
    }
}

