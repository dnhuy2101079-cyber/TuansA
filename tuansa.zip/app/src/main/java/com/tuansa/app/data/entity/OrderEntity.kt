package com.tuansa.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val zone: String,
    val tableNumber: Int,
    val guests: Int,
    val note: String? = null,
    val createdAtEpochMillis: Long,
)

