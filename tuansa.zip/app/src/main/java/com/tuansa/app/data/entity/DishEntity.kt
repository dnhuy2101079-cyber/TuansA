package com.tuansa.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dishes")
data class DishEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val groupId: Long? = null,
    val imagePath: String? = null,
    val suggestedAddOnIds: List<Long> = emptyList(),
)

