package com.tuansa.app.ui.manage

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.tuansa.app.data.entity.DishEntity
import com.tuansa.app.util.ImageStore
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DishEditorDialog(
    initialDish: DishEntity?,
    allDishes: List<DishEntity>,
    groups: List<String>,
    onDismiss: () -> Unit,
    onSave: (id: Long, name: String, groupName: String?, imagePath: String?, addOnIds: List<Long>) -> Unit,
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initialDish?.name.orEmpty()) }
    var groupInput by remember { mutableStateOf("") }
    var imagePath by remember { mutableStateOf(initialDish?.imagePath) }
    var selectedAddOns by remember { mutableStateOf(initialDish?.suggestedAddOnIds ?: emptyList()) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri: Uri? ->
        if (uri != null) {
            val copied = ImageStore.copyToInternal(context, uri)
            if (copied != null) imagePath = copied
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    val g = groupInput.trim().takeIf { it.isNotBlank() }
                    onSave(
                        initialDish?.id ?: 0,
                        name,
                        g,
                        imagePath,
                        selectedAddOns,
                    )
                },
                enabled = name.trim().isNotBlank(),
            ) {
                Text("Lưu")
            }
        },
        dismissButton = { Button(onClick = onDismiss) { Text("Hủy") } },
        title = { Text(if ((initialDish?.id ?: 0) == 0L) "Thêm món" else "Sửa món") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Tên món") },
                )
                OutlinedTextField(
                    value = groupInput,
                    onValueChange = { groupInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Nhóm món (tùy chọn)") },
                    placeholder = { Text("Ví dụ: Hải sản") },
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            launcher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                            )
                        },
                    ) {
                        Text("Chọn ảnh")
                    }
                    Button(onClick = { imagePath = null }) { Text("Xóa ảnh") }
                }
                val path = imagePath
                if (!path.isNullOrBlank()) {
                    AsyncImage(
                        model = File(path),
                        contentDescription = "Ảnh món",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Nhóm bán kèm (tùy chọn)",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                val available = allDishes.filter { it.id != initialDish?.id && it.id != 0L }
                if (available.isEmpty()) {
                    Text(
                        text = "Chưa có món nào khác để chọn bán kèm.",
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f),
                    )
                } else {
                    available.take(30).forEach { dish ->
                        val checked = selectedAddOns.contains(dish.id)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = dish.name,
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.onBackground,
                            )
                            Button(
                                onClick = {
                                    selectedAddOns = if (checked) {
                                        selectedAddOns - dish.id
                                    } else {
                                        selectedAddOns + dish.id
                                    }
                                },
                            ) {
                                Text(if (checked) "Bỏ" else "Thêm")
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    if (available.size > 30) {
                        Text(
                            text = "Đang hiển thị 30 món để chọn bán kèm.",
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        },
    )
}
