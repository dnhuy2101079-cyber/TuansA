package com.tuansa.app

import android.content.Context
import com.tuansa.app.data.AppDatabase
import com.tuansa.app.data.repo.MenuRepository
import com.tuansa.app.data.repo.OrderRepository
import com.tuansa.app.data.repo.PrinterRepository

object AppGraph {
    private lateinit var appContext: Context

    val db: AppDatabase by lazy { AppDatabase.create(appContext) }

    val menuRepository: MenuRepository by lazy { MenuRepository(db.dishGroupDao(), db.dishDao()) }
    val printerRepository: PrinterRepository by lazy { PrinterRepository(db.printerDao()) }
    val orderRepository: OrderRepository by lazy { OrderRepository(db.orderDao(), db.orderItemDao(), db.dishDao()) }

    fun init(context: Context) {
        appContext = context.applicationContext
    }
}

