package com.tuansa.app.ui.manage

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tuansa.app.data.entity.PrinterEntity
import com.tuansa.app.data.entity.PrinterRole

@Composable
fun PrinterManagePane(
    printerVm: PrinterManageViewModel,
) {
    val printers by printerVm.printers.collectAsStateWithLifecycle()
    val testState by printerVm.testState.collectAsStateWithLifecycle()

    var editing by remember { mutableStateOf<PrinterEntity?>(null) }
    var confirmDelete by remember { mutableStateOf<PrinterEntity?>(null) }

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Máy in",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f),
            )
            FloatingActionButton(onClick = { editing = PrinterEntity(name = "", ip = "") }) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Thêm máy in")
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(printers, key = { it.id }) { printer ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(printer.name.ifBlank { "(Chưa đặt tên)" }, color = MaterialTheme.colorScheme.onBackground)
                        Text(
                            text = "${printer.ip}:${printer.port} • ${roleLabel(printer.role)}",
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    IconButton(onClick = { editing = printer }) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Sửa")
                    }
                    IconButton(onClick = { confirmDelete = printer }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Xóa")
                    }
                }
            }
            if (printers.isEmpty()) {
                item("empty") {
                    Text(
                        text = "Chưa có máy in. Hãy thêm máy in Bếp và Quầy thu ngân.",
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
            }
            item("spacer-bottom") { Spacer(modifier = Modifier.height(90.dp)) }
        }
    }

    if (editing != null) {
        PrinterEditorDialog(
            initial = editing,
            onDismiss = { editing = null },
            onSave = { id, name, ip, port, role, strip ->
                printerVm.savePrinter(
                    id = id,
                    name = name,
                    ip = ip,
                    port = port,
                    role = role,
                    stripDiacritics = strip,
                    onDone = { editing = null },
                )
            },
            onTest = { ip, port, strip ->
                printerVm.testPrinter(ip, port, strip)
            },
        )
    }

    if (confirmDelete != null) {
        val printer = confirmDelete!!
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            confirmButton = {
                Button(
                    onClick = {
                        printerVm.deletePrinter(printer)
                        confirmDelete = null
                    },
                ) {
                    Text("Xóa")
                }
            },
            dismissButton = {
                Button(onClick = { confirmDelete = null }) { Text("Hủy") }
            },
            title = { Text("Xóa máy in") },
            text = { Text("Xóa máy in \"${printer.name}\"?") },
        )
    }

    when (testState) {
        is PrinterTestState.Success -> {
            AlertDialog(
                onDismissRequest = { printerVm.clearTestState() },
                confirmButton = { Button(onClick = { printerVm.clearTestState() }) { Text("Đóng") } },
                title = { Text("In thử") },
                text = { Text((testState as PrinterTestState.Success).message) },
            )
        }

        is PrinterTestState.Error -> {
            AlertDialog(
                onDismissRequest = { printerVm.clearTestState() },
                confirmButton = { Button(onClick = { printerVm.clearTestState() }) { Text("Đóng") } },
                title = { Text("In thử thất bại") },
                text = { Text((testState as PrinterTestState.Error).message) },
            )
        }

        else -> Unit
    }
}

private fun roleLabel(role: PrinterRole): String {
    return when (role) {
        PrinterRole.KITCHEN -> "Bếp"
        PrinterRole.CASHIER -> "Quầy"
    }
}

