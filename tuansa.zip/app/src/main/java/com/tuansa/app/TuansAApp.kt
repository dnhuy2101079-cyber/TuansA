package com.tuansa.app

import android.app.Application

class TuansAApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
    }
}

