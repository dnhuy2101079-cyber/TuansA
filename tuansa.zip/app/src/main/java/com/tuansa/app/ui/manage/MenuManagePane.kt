package com.tuansa.app.ui.manage

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tuansa.app.data.entity.DishEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuManagePane(
    menuVm: MenuManageViewModel,
) {
    val groups by menuVm.groups.collectAsStateWithLifecycle()
    val dishes by menuVm.dishes.collectAsStateWithLifecycle()

    var editing by remember { mutableStateOf<DishEntity?>(null) }
    var confirmDelete by remember { mutableStateOf<DishEntity?>(null) }

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Danh sách món",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f),
            )
            FloatingActionButton(onClick = { editing = DishEntity(name = "") }) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Thêm món")
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(dishes, key = { it.id }) { dish ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(dish.name.ifBlank { "(Chưa đặt tên)" }, color = MaterialTheme.colorScheme.onBackground)
                        val groupName = dish.groupId?.let { gid -> groups.firstOrNull { it.id == gid }?.name }
                        if (!groupName.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = groupName,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f),
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                    IconButton(onClick = { editing = dish }) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Sửa")
                    }
                    IconButton(onClick = { confirmDelete = dish }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Xóa")
                    }
                }
            }
            if (dishes.isEmpty()) {
                item("empty") {
                    Text(
                        text = "Chưa có món nào.",
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                }
            }
            item("spacer-bottom") { Spacer(modifier = Modifier.height(90.dp)) }
        }
    }

    if (editing != null) {
        DishEditorDialog(
            initialDish = editing,
            allDishes = dishes,
            groups = groups.map { it.name },
            onDismiss = { editing = null },
            onSave = { id, name, groupName, imagePath, addOnIds ->
                menuVm.saveDish(
                    id = id,
                    name = name,
                    groupName = groupName,
                    imagePath = imagePath,
                    suggestedAddOnIds = addOnIds,
                    onDone = { editing = null },
                )
            },
        )
    }

    if (confirmDelete != null) {
        val dish = confirmDelete!!
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            confirmButton = {
                Button(
                    onClick = {
                        menuVm.deleteDish(dish)
                        confirmDelete = null
                    },
                ) {
                    Text("Xóa")
                }
            },
            dismissButton = {
                Button(onClick = { confirmDelete = null }) { Text("Hủy") }
            },
            title = { Text("Xóa món") },
            text = { Text("Xóa món \"${dish.name}\"?") },
        )
    }
}

