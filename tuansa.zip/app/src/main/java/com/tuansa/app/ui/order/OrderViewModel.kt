package com.tuansa.app.ui.order

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tuansa.app.data.entity.PrinterRole
import com.tuansa.app.data.repo.MenuRepository
import com.tuansa.app.data.repo.OrderLineInput
import com.tuansa.app.data.repo.OrderRepository
import com.tuansa.app.data.repo.PrinterRepository
import com.tuansa.app.printing.NetworkPrinterClient
import com.tuansa.app.printing.ReceiptFormatter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DraftLine(
    val dishId: Long,
    val quantity: Int,
    val addOnDishIds: List<Long> = emptyList(),
)

sealed class CheckoutResult {
    data object Idle : CheckoutResult()
    data object Printing : CheckoutResult()
    data class Success(val orderId: Long) : CheckoutResult()
    data class Error(val message: String) : CheckoutResult()
}

class OrderViewModel(
    private val menuRepository: MenuRepository,
    private val printerRepository: PrinterRepository,
    private val orderRepository: OrderRepository,
) : ViewModel() {
    val groups = menuRepository.observeGroups().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val dishes = menuRepository.observeDishes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _draftLines = MutableStateFlow<Map<Long, DraftLine>>(emptyMap())
    val draftLines: StateFlow<Map<Long, DraftLine>> = _draftLines.asStateFlow()

    private val _note = MutableStateFlow("")
    val note: StateFlow<String> = _note.asStateFlow()

    private val _checkoutResult = MutableStateFlow<CheckoutResult>(CheckoutResult.Idle)
    val checkoutResult: StateFlow<CheckoutResult> = _checkoutResult.asStateFlow()

    fun setNote(value: String) {
        _note.value = value
    }

    fun addDish(dishId: Long) {
        val current = _draftLines.value[dishId]
        val next = if (current == null) {
            DraftLine(dishId = dishId, quantity = 1)
        } else {
            current.copy(quantity = current.quantity + 1)
        }
        _draftLines.value = _draftLines.value.toMutableMap().apply { put(dishId, next) }
    }

    fun removeDish(dishId: Long) {
        val current = _draftLines.value[dishId] ?: return
        val map = _draftLines.value.toMutableMap()
        val nextQty = current.quantity - 1
        if (nextQty <= 0) map.remove(dishId) else map[dishId] = current.copy(quantity = nextQty)
        _draftLines.value = map
    }

    fun clearDraft() {
        _draftLines.value = emptyMap()
        _note.value = ""
        _checkoutResult.value = CheckoutResult.Idle
    }

    fun checkoutAndPrint(zone: String, table: Int, guests: Int) {
        if (_checkoutResult.value is CheckoutResult.Printing) return
        val lines = _draftLines.value.values.toList()
        if (lines.isEmpty()) {
            _checkoutResult.value = CheckoutResult.Error("Chưa chọn món nào.")
            return
        }
        _checkoutResult.value = CheckoutResult.Printing
        viewModelScope.launch {
            runCatching {
                val kitchenPrinters = printerRepository.getByRole(PrinterRole.KITCHEN)
                val cashierPrinters = printerRepository.getByRole(PrinterRole.CASHIER)
                if (kitchenPrinters.isEmpty()) error("Chưa cấu hình máy in Bếp.")
                if (cashierPrinters.isEmpty()) error("Chưa cấu hình máy in Quầy thu ngân.")

                val orderId = orderRepository.createOrder(
                    zone = zone,
                    tableNumber = table,
                    guests = guests,
                    note = _note.value,
                    lines = lines.map { OrderLineInput(it.dishId, it.quantity, it.addOnDishIds) },
                    createdAtEpochMillis = System.currentTimeMillis(),
                )
                val printData = orderRepository.loadPrintData(orderId) ?: error("Không tạo được dữ liệu in.")

                val kitchen = kitchenPrinters.first()
                val cashier = cashierPrinters.first()

                val kitchenBytes = ReceiptFormatter.buildReceiptBytes(
                    header = "BEP",
                    data = printData,
                    stripDiacritics = kitchen.stripDiacritics,
                )
                val cashierBytes = ReceiptFormatter.buildReceiptBytes(
                    header = "THU NGAN",
                    data = printData,
                    stripDiacritics = cashier.stripDiacritics,
                )

                NetworkPrinterClient.print(kitchen.ip, kitchen.port, kitchenBytes)
                NetworkPrinterClient.print(cashier.ip, cashier.port, cashierBytes)

                orderId
            }.onSuccess { orderId ->
                _checkoutResult.value = CheckoutResult.Success(orderId)
            }.onFailure { t ->
                _checkoutResult.value = CheckoutResult.Error(t.message ?: "In bill thất bại.")
            }
        }
    }
}

