package com.tuansa.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.tuansa.app.data.dao.DishDao
import com.tuansa.app.data.dao.DishGroupDao
import com.tuansa.app.data.dao.OrderDao
import com.tuansa.app.data.dao.OrderItemDao
import com.tuansa.app.data.dao.PrinterDao
import com.tuansa.app.data.entity.DishEntity
import com.tuansa.app.data.entity.DishGroupEntity
import com.tuansa.app.data.entity.OrderEntity
import com.tuansa.app.data.entity.OrderItemEntity
import com.tuansa.app.data.entity.PrinterEntity

@Database(
    entities = [
        DishGroupEntity::class,
        DishEntity::class,
        PrinterEntity::class,
        OrderEntity::class,
        OrderItemEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
@TypeConverters(RoomConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dishGroupDao(): DishGroupDao
    abstract fun dishDao(): DishDao
    abstract fun printerDao(): PrinterDao
    abstract fun orderDao(): OrderDao
    abstract fun orderItemDao(): OrderItemDao

    companion object {
        fun create(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context,
                AppDatabase::class.java,
                "tuansa.db",
            ).fallbackToDestructiveMigration().build()
        }
    }
}

