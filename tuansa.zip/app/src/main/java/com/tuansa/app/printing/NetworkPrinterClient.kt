package com.tuansa.app.printing

import java.net.InetSocketAddress
import java.net.Socket

object NetworkPrinterClient {
    fun print(ip: String, port: Int, bytes: ByteArray, timeoutMs: Int = 4000) {
        Socket().use { socket ->
            socket.soTimeout = timeoutMs
            socket.connect(InetSocketAddress(ip, port), timeoutMs)
            socket.getOutputStream().use { out ->
                out.write(bytes)
                out.flush()
            }
        }
    }
}

