package com.tuansa.app.ui.manage

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tuansa.app.data.entity.DishEntity
import com.tuansa.app.data.entity.DishGroupEntity
import com.tuansa.app.data.repo.MenuRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MenuManageViewModel(
    private val menuRepository: MenuRepository,
) : ViewModel() {
    val groups = menuRepository.observeGroups().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val dishes = menuRepository.observeDishes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun deleteDish(entity: DishEntity) {
        viewModelScope.launch { menuRepository.deleteDish(entity) }
    }

    fun saveDish(
        id: Long,
        name: String,
        groupName: String?,
        imagePath: String?,
        suggestedAddOnIds: List<Long>,
        onDone: () -> Unit,
    ) {
        viewModelScope.launch {
            val groupId = groupName?.trim()?.takeIf { it.isNotBlank() }?.let { gName ->
                val existing = groups.value.firstOrNull { it.name.equals(gName, ignoreCase = true) }
                existing?.id ?: menuRepository.upsertGroup(DishGroupEntity(name = gName))
            }
            menuRepository.upsertDish(
                DishEntity(
                    id = id,
                    name = name.trim(),
                    groupId = groupId,
                    imagePath = imagePath,
                    suggestedAddOnIds = suggestedAddOnIds,
                ),
            )
            onDone()
        }
    }
}

