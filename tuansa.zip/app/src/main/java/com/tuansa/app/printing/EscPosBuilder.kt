package com.tuansa.app.printing

import java.io.ByteArrayOutputStream
import java.nio.charset.Charset

class EscPosBuilder(
    private val charset: Charset = Charsets.US_ASCII,
) {
    private val out = ByteArrayOutputStream()

    fun init(): EscPosBuilder {
        out.write(byteArrayOf(0x1B, 0x40))
        return this
    }

    fun alignLeft(): EscPosBuilder {
        out.write(byteArrayOf(0x1B, 0x61, 0x00))
        return this
    }

    fun alignCenter(): EscPosBuilder {
        out.write(byteArrayOf(0x1B, 0x61, 0x01))
        return this
    }

    fun bold(on: Boolean): EscPosBuilder {
        out.write(byteArrayOf(0x1B, 0x45, if (on) 0x01 else 0x00))
        return this
    }

    fun textLine(text: String): EscPosBuilder {
        out.write(text.toByteArray(charset))
        out.write(0x0A)
        return this
    }

    fun feed(lines: Int): EscPosBuilder {
        repeat(lines.coerceAtLeast(0)) { out.write(0x0A) }
        return this
    }

    fun cut(): EscPosBuilder {
        out.write(byteArrayOf(0x1D, 0x56, 0x01))
        return this
    }

    fun build(): ByteArray = out.toByteArray()
}

