package com.tuansa.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TuansABlue = Color(0xFF0B5ED7)
private val TuansABlueDark = Color(0xFF084298)

private val DarkColorScheme = darkColorScheme(
    primary = TuansABlue,
    secondary = TuansABlueDark,
    background = TuansABlueDark,
    surface = TuansABlueDark,
)

private val LightColorScheme = lightColorScheme(
    primary = TuansABlue,
    secondary = TuansABlueDark,
    background = TuansABlue,
    surface = TuansABlue,
)

@Composable
fun TuansATheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val scheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = scheme,
        content = content,
    )
}

