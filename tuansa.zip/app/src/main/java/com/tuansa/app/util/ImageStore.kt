package com.tuansa.app.util

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.UUID

object ImageStore {
    fun copyToInternal(context: Context, source: Uri): String? {
        return runCatching {
            val dir = File(context.filesDir, "images").apply { mkdirs() }
            val file = File(dir, "${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(source)?.use { input ->
                file.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return null
            file.absolutePath
        }.getOrNull()
    }
}

