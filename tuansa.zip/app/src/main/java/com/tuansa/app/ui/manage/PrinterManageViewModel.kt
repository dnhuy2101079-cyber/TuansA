package com.tuansa.app.ui.manage

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tuansa.app.data.entity.PrinterEntity
import com.tuansa.app.data.entity.PrinterRole
import com.tuansa.app.data.repo.PrinterRepository
import com.tuansa.app.printing.EscPosBuilder
import com.tuansa.app.printing.NetworkPrinterClient
import com.tuansa.app.util.VietnameseText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class PrinterTestState {
    data object Idle : PrinterTestState()
    data object Testing : PrinterTestState()
    data class Success(val message: String) : PrinterTestState()
    data class Error(val message: String) : PrinterTestState()
}

class PrinterManageViewModel(
    private val printerRepository: PrinterRepository,
) : ViewModel() {
    val printers = printerRepository.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _testState = MutableStateFlow<PrinterTestState>(PrinterTestState.Idle)
    val testState: StateFlow<PrinterTestState> = _testState.asStateFlow()

    fun clearTestState() {
        _testState.value = PrinterTestState.Idle
    }

    fun deletePrinter(entity: PrinterEntity) {
        viewModelScope.launch { printerRepository.delete(entity) }
    }

    fun savePrinter(
        id: Long,
        name: String,
        ip: String,
        port: Int,
        role: PrinterRole,
        stripDiacritics: Boolean,
        onDone: () -> Unit,
    ) {
        viewModelScope.launch {
            printerRepository.upsert(
                PrinterEntity(
                    id = id,
                    name = name.trim(),
                    ip = ip.trim(),
                    port = port,
                    role = role,
                    stripDiacritics = stripDiacritics,
                ),
            )
            onDone()
        }
    }

    fun testPrinter(ip: String, port: Int, stripDiacritics: Boolean) {
        if (_testState.value is PrinterTestState.Testing) return
        _testState.value = PrinterTestState.Testing
        viewModelScope.launch {
            runCatching {
                val text = if (stripDiacritics) {
                    VietnameseText.stripDiacritics("TuansA - In thử")
                } else {
                    "TuansA - In thử"
                }
                val bytes = EscPosBuilder()
                    .init()
                    .alignCenter()
                    .bold(true)
                    .textLine(text)
                    .bold(false)
                    .feed(2)
                    .cut()
                    .build()
                NetworkPrinterClient.print(ip, port, bytes)
            }.onSuccess {
                _testState.value = PrinterTestState.Success("Đã gửi lệnh in thử.")
            }.onFailure { t ->
                _testState.value = PrinterTestState.Error(t.message ?: "In thử thất bại.")
            }
        }
    }
}

