package com.tuansa.app.printing

import com.tuansa.app.data.repo.OrderPrintData
import com.tuansa.app.util.VietnameseText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReceiptFormatter {
    private const val LineWidth = 48

    fun buildReceiptBytes(
        header: String,
        data: OrderPrintData,
        stripDiacritics: Boolean,
    ): ByteArray {
        val builder = EscPosBuilder()
            .init()
            .alignCenter()
            .bold(true)
            .textLine(sanitize(header, stripDiacritics))
            .bold(false)
            .feed(1)

        val time = formatTime(data.order.createdAtEpochMillis)
        val zoneTable = "${data.order.zone} - Ban ${data.order.tableNumber}"
        val totalQty = data.lines.sumOf { it.quantity }
        val totalKinds = data.lines.size

        builder.alignLeft()
        builder.textLine(sanitize(zoneTable, stripDiacritics))
        builder.textLine(sanitize("Thoi gian: $time", stripDiacritics))
        builder.textLine(sanitize("So khach: ${data.order.guests}", stripDiacritics))
        builder.textLine(sanitize("So luong mon: $totalQty ($totalKinds loai)", stripDiacritics))
        data.order.note?.takeIf { it.isNotBlank() }?.let {
            builder.textLine(sanitize("Ghi chu: $it", stripDiacritics))
        }
        builder.textLine("-".repeat(LineWidth))

        data.lines.forEach { line ->
            val name = sanitize(line.dish.name, stripDiacritics)
            builder.bold(true).textLine(sanitize("x${line.quantity}  $name", stripDiacritics)).bold(false)
            line.addOns.forEach { addOn ->
                builder.textLine(sanitize("   + ${addOn.name}", stripDiacritics))
            }
            builder.textLine("-".repeat(LineWidth))
        }

        builder.feed(2).cut()
        return builder.build()
    }

    private fun formatTime(epochMillis: Long): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return sdf.format(Date(epochMillis))
    }

    private fun sanitize(text: String, stripDiacritics: Boolean): String {
        return if (stripDiacritics) VietnameseText.stripDiacritics(text) else text
    }
}

